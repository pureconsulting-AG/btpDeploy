import express, { response } from "express";
import fetch from "node-fetch";
//const express = require('express');
//const fetch = require('node-fetch');

const app = express();
const port = process.env.PORT || 5000;
const apikey = process.env.API_KEY || ``;

app.use(express.json());

app.get("/", (req, res) => {
    res.status(200).send("Weather API is running");
});

app.get("/weather", async (req, res) => {
    if (!req.query.city) {
        res.status(404).json("City is missingclear");
    } else {
        let city = req.query.city;
        const response = await fetch(
            `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apikey}`
          );
      
          const data = await response.json();
          res.status(200).json(data);
    }
});

//creating server
app.listen(port, () => {
    console.log(`server is up on ${port}`);
});
import Module from "node:module";

const require = Module.createRequire(import.meta.url);
const express = require('express');
const passport = require('passport');
const xsenv = require('@sap/xsenv');
const { JWTStrategy } = require("@sap/xssec").v3;

const app = express();
const port = 9999; // set preferred port
const apikey = ``; // add open weather api key

app.use(express.json());

const services = xsenv.getServices({ uaa:'nodeuaa' });

passport.use(new JWTStrategy(services.uaa));

app.use(passport.initialize());
app.use(passport.authenticate('JWT', { session: false }));

app.get("/", (req, res) => {
    res.status(200).send("Weather API is running");
});

app.get("/weather", async (req, res) => {
    if (!req.query.city) {
        res.status(404).json("City is missingclear");
    } else {
        let city = req.query.city;
        const response = await fetch(
            `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apikey}`
          );
      
          const data = await response.json();
          res.status(200).json(data);
    }
});

//creating server
app.listen(port, () => {
    console.log(`server is up on ${port}`);
});